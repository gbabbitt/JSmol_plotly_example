Clazz.declarePackage ("J.api");
c$ = Clazz.declareInterface (J.api, "JmolGestureServerInterface");
Clazz.defineStatics (c$,
"OK", 1,
"HAS_CLIENT", 2,
"HAS_DRIVER", 4);
