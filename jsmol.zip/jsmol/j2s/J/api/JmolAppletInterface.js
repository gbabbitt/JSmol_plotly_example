Clazz.declarePackage ("J.api");
Clazz.load (["J.api.JmolSyncInterface"], "J.api.JmolAppletInterface", null, function () {
Clazz.declareInterface (J.api, "JmolAppletInterface", J.api.JmolSyncInterface);
});
