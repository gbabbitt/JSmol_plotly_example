Clazz.declarePackage ("J.api.js");
Clazz.load (["javajs.api.js.JSAppletObject"], "J.api.js.JSmolAppletObject", null, function () {
Clazz.declareInterface (J.api.js, "JSmolAppletObject", javajs.api.js.JSAppletObject);
});
