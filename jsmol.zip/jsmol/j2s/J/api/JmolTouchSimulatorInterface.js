Clazz.declarePackage ("J.api");
Clazz.declareInterface (J.api, "JmolTouchSimulatorInterface");
