Clazz.declarePackage ("J.api");
c$ = Clazz.declareInterface (J.api, "JmolScriptManager");
Clazz.defineStatics (c$,
"PDB_CARTOONS", 1,
"NO_SCRIPT", 2,
"IS_APPEND", 4,
"NO_AUTOPLAY", 8,
"FILE_DROPPED", 16);
