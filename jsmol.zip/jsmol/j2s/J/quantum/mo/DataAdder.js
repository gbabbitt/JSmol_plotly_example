Clazz.declarePackage ("J.quantum.mo");
Clazz.declareInterface (J.quantum.mo, "DataAdder");
