<?php

phpinfo():

>?


